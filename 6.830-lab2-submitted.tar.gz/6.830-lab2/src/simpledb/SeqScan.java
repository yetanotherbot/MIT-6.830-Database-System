package simpledb;
import java.util.*;

/**
 * SeqScan is an implementation of a sequential scan access method that reads
 * each tuple of a table in no particular order (e.g., as they are laid out on
 * disk).
 */
public class SeqScan implements DbIterator {

    private DbFileIterator dbfItr;
    private DbFile dbf;
    private TupleDesc aliasTd;
    /**
     * Creates a sequential scan over the specified table as a part of the
     * specified transaction.
     *
     * @param tid The transaction this scan is running as a part of.
     * @param tableid the table to scan.
     * @param tableAlias the alias of this table (needed by the parser);
     *         the returned tupleDesc should have fields with name tableAlias.fieldName
     *         (note: this class is not responsible for handling a case where tableAlias
     *         or fieldName are null.  It shouldn't crash if they are, but the resulting
     *         name can be null.fieldName, tableAlias.null, or null.null).
     */
    public SeqScan(TransactionId tid, int tableid, String tableAlias) {
        // some code goes here
        dbf = Database.getCatalog().getDbFile(tableid);
        dbfItr = dbf.iterator(tid);
        TupleDesc td = dbf.getTupleDesc();
        int aliasNumFields = td.numFields();
        Type[] aliasTypes = new Type[aliasNumFields];
        String[] aliasFields = new String[aliasNumFields];
        for (int i = 0; i < td.numFields(); ++i) {
            aliasTypes[i] = td.getType(i);
            if (tableAlias != null && tableAlias.length() == 0)
                aliasFields[i] = String.valueOf(td.getFieldName(i));
            else aliasFields[i] = String.valueOf(tableAlias) + "." + String.valueOf(td.getFieldName(i));
        }
        aliasTd = new TupleDesc(aliasTypes, aliasFields);
    }

    public void open()
        throws DbException, TransactionAbortedException {
        // some code goes here
        dbfItr.open();
    }

    /**
     * Returns the TupleDesc with field names from the underlying HeapFile,
     * prefixed with the tableAlias string from the constructor.
     * @return the TupleDesc with field names from the underlying HeapFile,
     * prefixed with the tableAlias string from the constructor.
     */
    public TupleDesc getTupleDesc() {
        // some code goes here
        return aliasTd;
    }

    public boolean hasNext() throws TransactionAbortedException, DbException {
        // some code goes here
        return dbfItr.hasNext();
    }

    public Tuple next()
        throws NoSuchElementException, TransactionAbortedException, DbException {
        // some code goes here
        return dbfItr.next();
    }

    public void close() {
        dbfItr.close();
    }

    public void rewind()
        throws DbException, NoSuchElementException, TransactionAbortedException {
        dbfItr.rewind();
    }
}
